﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using Sirenix.Serialization;

[CreateAssetMenu(fileName ="SquareTableValue", menuName = "Chess", order = 0)]
public class SquareTableValues : SerializedScriptableObject {

    [TableMatrix][OdinSerialize]
    [ShowInInspector]
    public int[,] squareValues = new int[8,8]; 
}

